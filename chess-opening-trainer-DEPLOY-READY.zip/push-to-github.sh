#!/bin/bash
# =====================================================
# Chess Opening Trainer - GitHub Push Script
# =====================================================
# Run: bash push-to-github.sh
# =====================================================

REPO_URL="https://github.com/mluqman745745-cpu/chess-opening-trainer.git"

echo "🚀 Chess Opening Trainer - GitHub Push"
echo "======================================="

cd chess-opening-trainer-main

# Add remote and push
git remote add origin "$REPO_URL" 2>/dev/null || git remote set-url origin "$REPO_URL"
echo "✓ Remote set: $REPO_URL"

echo ""
echo "📤 Pushing to GitHub..."
git push -f origin main

echo ""
echo "✅ Done! Check: https://github.com/mluqman745745-cpu/chess-opening-trainer"
echo ""
echo "🎯 Now deploy on Vercel:"
echo "   1. vercel.com → Add New Project"
echo "   2. Import: chess-opening-trainer"
echo "   3. Click Deploy!"
